<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php

    require_once "$root/app/includes/cdns.php";
    echo "<title>$server</title>
          <link rel='stylesheet' href='$baseurl/app/styles/config/system-vars.css'>
          <link rel='stylesheet' href='$baseurl/app/styles/config/config.css'>
          <link href='https://fonts.googleapis.com/css2?family=Fira+Code:wght@300..700&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap' rel='stylesheet'>
          <link href='https://fonts.googleapis.com/css2?family=Fira+Code:wght@300..700&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap' rel='stylesheet'>

          ";

    ?>