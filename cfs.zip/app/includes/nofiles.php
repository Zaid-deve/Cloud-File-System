<div class="position-absolute top-50 start-50 translate-middle">
    <div class="p-3 d-flex flex-center flex-column text-center">
        <img src="<?php echo "$baseurl/app/images/nofiles.png" ?>" alt="#" class="img-contain" height="240px">
        <h3>Nothing to show you at a movement</h3>
        <p>Got no files ?, start uploading you files end-to-end encrypted</p>
        <a href="/cfs/app/upload/upload.php" class="btn rounded-5 bg-prime-color has-icon px-5 py-3">
            <i class="fa-solid fa-upload icon-normal"></i>
            <span>Upload files</span>
        </a>
    </div>
</div>