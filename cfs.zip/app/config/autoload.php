<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/CFS/app/config/config.php';
require_once "$root/app/php/functions.php";
require_once "$root/app/db/db_conn.php";
require_once "$root/app/user/authenticate.php";