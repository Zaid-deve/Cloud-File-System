<?php

require_once "app/config/autoload.php";
require_once "app/php/b2/b2file.php";


require_once "app/includes/layout/head.php";

?>

<link rel="stylesheet" href="app/styles/file.css">
</head>

<body class="bg-dark">

    <div class="filw-wrapper bg-white">
        <div class="skelition"></div>
        i am wrapper
    </div>

</body>

</html>