<div class="h-100 w-100 d-flex flex-center">
    <div class="spinner-border text-warning spinner-border-custom" role="status" style="height: 40px;width:40px;border-width:1px">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>